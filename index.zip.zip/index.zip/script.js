function copyEmail() {
  const email = document.getElementById("email").textContent;
  navigator.clipboard.writeText(email).then(() => {
    alert("Email copied to clipboard!");
  });
}

function refreshInbox() {
  const inbox = document.getElementById("inbox");
  inbox.textContent = "📨 Inbox refreshed at " + new Date().toLocaleTimeString();
}

function toggleDarkMode() {
  document.body.classList.toggle("dark-mode");
}

// Auto-refresh inbox every 15 seconds
setInterval(refreshInbox, 15000);